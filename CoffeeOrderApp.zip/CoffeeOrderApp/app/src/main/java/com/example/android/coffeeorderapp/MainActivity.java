package com.example.android.coffeeorderapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addTopping(View view) {
        CheckBox checkBox = (CheckBox) view;
        if (checkBox.isChecked()) {
            switch (view.getId()) {
                case R.id.chocolate_checkbox:
                    increasePrice(5);
                    break;
                case R.id.whippedCream_checkbox:
                    increasePrice(3);
                    break;

            }
        } else {
            switch (view.getId()) {
                case R.id.chocolate_checkbox:
                    decreasePrice(5);
                    break;
                case R.id.whippedCream_checkbox:
                    decreasePrice(3);
                    break;

            }
        }
    }

    public void addItem(View view) {
        TextView textView = (TextView) findViewById(R.id.quantity_text_view);
        TextView view1 = (TextView) findViewById(R.id.thankYou_text_view);
        view1.setText("");

        String s = (String) textView.getText();
        int num = Integer.parseInt(s) + 1;
        textView.setText("" + num);
        increasePrice(10);
    }

    private void increasePrice(int val) {
        TextView textView = (TextView) findViewById(R.id.price_text_view);
        String s = (String) textView.getText();
        s = s.substring(0, s.length() - 1);
        int num = Integer.parseInt(s) + val;
        textView.setText("" + num + "$");
    }


    public void deleteItem(View view) {
        TextView textView = (TextView) findViewById(R.id.quantity_text_view);
        TextView view1 = (TextView) findViewById(R.id.thankYou_text_view);
        view1.setText("");
        String s = (String) textView.getText();
        int num = Integer.parseInt(s) - 1;
        if (num >= 0) {
            textView.setText("" + num);
            decreasePrice(10);
        }
    }

    private void decreasePrice(int val) {
        TextView textView = (TextView) findViewById(R.id.price_text_view);
        String s = (String) textView.getText();
        s = s.substring(0, s.length() - 1);
        int num = Integer.parseInt(s) - val;
        textView.setText("" + num + "$");
    }

    public void ordering(View view) {
        EditText text = findViewById(R.id.name);
        String name = text.getText().toString();
        CheckBox cream = findViewById(R.id.whippedCream_checkbox);
        CheckBox chocolate = findViewById(R.id.chocolate_checkbox);
        String creamChecked = (cream.isChecked()) ? "YES" : "NO";
        String chocolateChecked = (chocolate.isChecked()) ? "YES" : "NO";
        TextView qty = findViewById(R.id.quantity_text_view);
        String quantity = qty.getText().toString();
        TextView price = findViewById(R.id.price_text_view);
        String amount = price.getText().toString();
        String orderSummaryMessage =
                "Name : " + name +
                        "\nAdded Whipped Cream? " + creamChecked +
                        "\nAdded Chocolate? " + chocolateChecked +
                        "\nQuantity : " + quantity + "   Amount : " + amount;
        TextView textView = findViewById(R.id.thankYou_text_view);

/*      textView.setText(orderSummaryMessage);
        Toast.makeText(this, "Order placed successfully!", Toast.LENGTH_LONG).show();*/

        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("mailto:"));
        intent.putExtra(Intent.EXTRA_TEXT,orderSummaryMessage);
        intent.putExtra(Intent.EXTRA_SUBJECT,"Regarding the order placed");
        startActivity(intent);
    }


}