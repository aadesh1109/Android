package com.example.android.goalcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private int seconds = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle bundle = getIntent().getExtras();
        String nameA = bundle.getString("teamAName");
        String nameB = bundle.getString("teamBName");
        /*Intent i = getIntent(); //another way to get intent data
        String nameA = i.getStringExtra("teamAName");
        String nameB = i.getStringExtra("teamBName");*/
        TextView v1 = (TextView) findViewById(R.id.teamA);
        TextView v2 = (TextView) findViewById(R.id.teamB);
        v1.setText("Team "+ nameA);
        v2.setText("Team "+ nameB);
    }

    public void add3PointsForA(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamA_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+3;
        textView.setText(""+num);

    }

    public void add3PointsForB(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamB_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+3;
        textView.setText(""+num);
    }

    public void add2PointsForA(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamA_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+2;
        textView.setText(""+num);

    }

    public void add2PointsForB(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamB_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+2;
        textView.setText(""+num);
    }

    public void add1PointsForA(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamA_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+1;
        textView.setText(""+num);

    }

    public void add1PointsForB(View view)
    {
        TextView textView = (TextView) findViewById(R.id.teamB_points);
        String val = (String) textView.getText();
        int num = Integer.parseInt(val)+1;
        textView.setText(""+num);
    }

    public void resetIt(View view)
    {
        TextView textView1 = (TextView) findViewById(R.id.teamA_points);
        TextView textView2 = (TextView) findViewById(R.id.teamB_points);
        textView1.setText(""+0);
        textView2.setText(""+0);
    }

    public void startIt(View view)
    {

    }

    public void stopIt(View view)
    {
        Intent intent = new Intent(this,MainActivity3.class);
        TextView t1 = findViewById(R.id.teamA_points);
        TextView t2 = findViewById(R.id.teamB_points);
        TextView t1name = findViewById(R.id.teamA);
        TextView t2name = findViewById(R.id.teamB);
        int num1 = Integer.parseInt(t1.getText().toString());
        int num2 = Integer.parseInt(t2.getText().toString());
        String team1 = t1name.getText().toString();
        String team2 = t2name.getText().toString();
        if (num1>num2)
            intent.putExtra("winnerName",team1);
        else if (num2>num1)
            intent.putExtra("winnerName",team2);
        else
            intent.putExtra("winnerName","None");
        startActivity(intent);

    }
}