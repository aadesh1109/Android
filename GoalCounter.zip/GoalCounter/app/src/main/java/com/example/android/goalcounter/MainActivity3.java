package com.example.android.goalcounter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        TextView result = findViewById(R.id.result);
        Bundle bundle = getIntent().getExtras();
        String winner =  bundle.getString("winnerName");
        if (!winner.equals("None"))
            result.setText(winner + "\n wins!");
        else
            result.setText("Match\ntied!");


    }
}